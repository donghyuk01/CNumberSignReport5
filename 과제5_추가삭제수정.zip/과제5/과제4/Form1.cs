using Microsoft.VisualBasic.Devices;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Text;

namespace 과제4
{
    public partial class Form1 : Form
    {
        Form2 f2;
        Form3 f3;
        public int isLogin; //0: 로그인 1: 로그아웃
        private string login_id = "";
        string connStr = "Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd=civil5949;CharSet=utf8mb4;";
        public Form1()
        {
            InitializeComponent();
            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ListViewItem item = new ListViewItem("");
            isLogin = 1;
            
        }
        public string set_id
        {
            set 
            {
                login_id = value;
                comboBox1.Items.Add(value);
                comboBox1.SelectedItem = value;
                label2.Text = value + "님의 체크리스트";
                isLogin = 0;
                LoadItems();
            }
        }
        public void AddToListView(string todo, string dueDate, string priority, string date, object db_id = null, bool isChecked = false)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(date);
            listView1.Items.Add(item);

            if (db_id != null)
            {
                item.Tag = db_id;
            }
            item.Checked = isChecked;
        }
        private void LoadItems()
        {
            if (string.IsNullOrEmpty(login_id))
            {
                listView1.Items.Clear();
            }
            try
            {
                using(MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "select id_check_ToDo, todo, period, priority, status, dateTime from `1101`.check_ToDo where user_id = @user_id";
                    using(MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", login_id);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            listView1.Items.Clear();
                            while (reader.Read())
                            {
                                
                                object db_id = reader["id_check_ToDo"];
                                string todo = Convert.ToString(reader["todo"]);
                                string dueDate = Convert.ToString(reader["period"]);
                                string date = Convert.ToDateTime(reader["dateTime"]).ToString("yyyy-MM-dd");
                                
                                string priorityStr = "중간";
                                int p = Convert.ToInt32(reader["priority"]);
                                if (p == 1) priorityStr = "높음";
                                else if (p == 3) priorityStr = "낮음";


                                bool isChecked = Convert.ToString(reader["status"]) == "완료";


                                AddToListView(todo, dueDate, priorityStr,date,db_id,isChecked);
                            }
                        }
                    }
                }
                updateCheck();
            }
            catch(Exception e)
            {
                MessageBox.Show("데이터를 가져오는 중 오류가 발생했습니다:\n" + e, "오류");
            }
        }
        private void OpenOrActivateForm2(Size? customSize = null)
        {
            // 클릭하는 "현재 시점"에 실제로 열려있는 Form2를 찾습니다.
            if(isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 서비스입니다.");
                return;
            }
            f2 = Application.OpenForms["Form2"] as Form2;

            if (f2 == null || f2.IsDisposed)
            {
                // 열려있지 않거나 닫혔다면 새로 생성
                f2 = new Form2(this,login_id);
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                // 사용자가 Form2를 닫으면 전역 변수 f2도 null로 초기화하여 중복 방지
                f2.FormClosed += (s, args) => { f2 = null; };
                f2.Show();
            }
            else
            {
                // 이미 열려 있다면 위치/크기 조정 후 앞으로 가져오기
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.Activate();
            }

        }
        private void edit_dialog_Click(object sender, EventArgs e)
        {
            OpenOrActivateForm2(new Size(540, 320));
        }

        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            bool find = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[1].Text.Contains(s))
                {
                    item.BackColor = Color.Yellow;
                    item.EnsureVisible(); //항목 위치로 스크롤되게 
                    //textBox_search.Clear();
                    find = true;
                }
                else
                {
                    item.BackColor = Color.White;
                }
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;     // 할 일
                string thirdColumn = item.SubItems[2].Text;     // 날짜
                string forthColumn = item.SubItems[3].Text;     // 우선순위
                if (f2 != null)
                {
                    f2.SetToDo = secondColumn;
                    f2.SetDate = thirdColumn;
                    f2.SetSelect = forthColumn;
                    f2.SetItem = item;
                }

            }
        }
        public void deleteItems()
        {
            int c = listView1.SelectedItems.Count;
            if (c > 0)
            {
                for (int i = c - 1; i >= 0; i--)
                {
                    listView1.Items.Remove(listView1.SelectedItems[i]);
                }
            }
        }

        private int sortColumn = -1;
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == sortColumn)
            {
                // 같은 열 클릭시 오름차순/내림차순 토글
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                // 다른 열 클릭시 오름차순으로 시작
                sortColumn = e.Column;
                listView1.Sorting = SortOrder.Ascending;
            }

            listView1.ListViewItemSorter = new ListViewItemComparer(sortColumn, listView1.Sorting);
            // 사용이유 ListViewItemSorter ListView의 정렬 방법 정의
            // 높음, 중간, 낮음이 기존 정렬로는 정렬이 안됨 낮음->높음->중간 순
            // 그래서 정렬 방법을 아이템 3번만 정의
            // IComparer 인터페이스로만 받을수 있어서 클래스 새롭게 정의함
            listView1.Sort();
        }
        public void updateCheck()
        {
            int total = listView1.Items.Count;
            int count = listView1.CheckedItems.Count;

            textBox_state.Text = $"완료된 할 일: {count} / {total}";
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            updateCheck();
            if (e.Item != null && e.Item.Tag != null)
            {
                object db_id = e.Item.Tag; 
                string newStatus = e.Item.Checked ? "완료" : "미완료";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "update `1101`.check_ToDo set status = @status where id_check_ToDo = @id";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@status", newStatus);
                            cmd.Parameters.AddWithValue("@id", db_id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
                }
            }
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_search.Text))
            {
                // 검색 창을 지웠을때 작동
                foreach (ListViewItem item in listView1.Items)
                {
                    item.BackColor = Color.White;
                }
            }
        }

        private void share_Click(object sender, EventArgs e)
        {
            OpenOrActivateForm2(new Size(540, 320));
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            Form existingForm = Application.OpenForms["Form3"];

            if (existingForm == null)
            {
                // 없으면 새로 열기
                Form3 f3 = new Form3(this);

                // 위치를 직접 지정하려면 StartPosition을 Manual로 설정
                f3.StartPosition = FormStartPosition.Manual;
                f3.Size = new Size(480, 250);
                // 원하는 좌표 지정 (예: 화면 왼쪽 위에서 100, 200 위치)
                f3.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                f3.Show();
            }
            else
            {
                existingForm.StartPosition = FormStartPosition.Manual;
                f3.Size = new Size(480,250);
                existingForm.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                // 이미 열려 있으면 앞으로 가져오기
                existingForm.Activate();
            }
        }
    }
}
public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder order)
    {
        col = column;
        this.order = order;
    }

    public int Compare(object x, object y)
    {
        string textX = ((ListViewItem)x).SubItems[col].Text;
        string textY = ((ListViewItem)y).SubItems[col].Text;

        int result;

        if (col == 3)  // 우선순위 열 커스텀 정렬
        {
            string[] order_list = { "낮음", "중간", "높음" };
            int indexX = Array.IndexOf(order_list, textX);
            int indexY = Array.IndexOf(order_list, textY);
            result = indexX.CompareTo(indexY);
        }
        else
        {
            result = String.Compare(textX, textY);
        }

        return order == SortOrder.Ascending ? result : -result;
    }

}