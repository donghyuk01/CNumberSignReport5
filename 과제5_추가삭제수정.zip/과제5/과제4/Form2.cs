﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO; // Stream 파일 입출력을 위해 필수 추가
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 과제4
{
    public partial class Form2 : Form
    {
        ListViewItem item;
        Form1 f1;
        private string login_id = "";

        
        string connStr = "Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd=civil5949;CharSet=utf8mb4;";

        public Form2()
        {
            InitializeComponent();
            this.Size = new Size(540, 320);
        }

        public Form2(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            dateTimePicker1.MinDate = DateTime.Today;
        }

        public Form2(Form1 f, string user_id)
        {
            InitializeComponent();
            f1 = f;
            login_id = user_id;
            dateTimePicker1.MinDate = DateTime.Today;
        }

        
        public string SetToDo
        {
            set { textBox_t.Text = value; }
        }
        public ListViewItem SetItem
        {
            set { item = value; }
        }
        public string SetDate
        {
            set { dateTimePicker1.Value = DateTime.Parse(value); }
        }
        public string SetSelect
        {
            set
            {
                if (value == "높음")
                    high.Checked = true;
                else if (value == "중간")
                    middle.Checked = true;
                else if (value == "낮음")
                    low.Checked = true;
            }
        }

        private bool input_date()
        {
            if (string.IsNullOrWhiteSpace(textBox_t.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox_t.Focus();
                return false;
            }

            if (!high.Checked && !middle.Checked && !low.Checked)
            {
                MessageBox.Show("우선순위를 선택해 주세요!", "알림");
                return false;
            }
            return true;
        }

        
        private void add_button_Click(object sender, EventArgs e)
        {
            if (!input_date())
            {
                return;
            }

            if (string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인 정보가 올바르지 않습니다.", "오류");
                return;
            }

            try
            {
                
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();

                    // 테이블 이름 백틱(`) 기호 및 공백 수정
                    string sql = "INSERT INTO `check_ToDo` (user_id, status, todo, period, priority, dateTime) VALUES (@user_id, @status, @todo, @period, @priority, @dateTime)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        
                        int priorityValue = 2;
                        string priorityStr = "중간";
                        if (high.Checked) { priorityValue = 1; priorityStr = "높음"; }
                        else if (low.Checked) { priorityValue = 3; priorityStr = "낮음"; }
                        string period = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                        cmd.Parameters.AddWithValue("@user_id", login_id);   
                        cmd.Parameters.AddWithValue("@status", "미완료");    
                        cmd.Parameters.AddWithValue("@todo", textBox_t.Text.Trim());
                        cmd.Parameters.AddWithValue("@period", period);
                        cmd.Parameters.AddWithValue("@priority", priorityValue);
                        cmd.Parameters.AddWithValue("@dateTime", dateTimePicker1.Value);


                        cmd.ExecuteScalar();
                        MessageBox.Show("DB에 할 일이 성공적으로 추가되었습니다.", "알림");

                        
                        if (f1 != null)
                        {
                            string todayStr = DateTime.Now.ToString("yyyy-MM-dd");
                            f1.AddToListView(textBox_t.Text.Trim(), period, priorityStr, todayStr, null, false);
                        }
                    }
                }

                if (f1 != null) f1.updateCheck();
                clearItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show("DB 저장 중 에러 발생: " + ex.Message, "오류");
            }
        }

        private void clearItems()
        {
            textBox_t.Clear();
            dateTimePicker1.Value = DateTime.Now;
            high.Checked = false;
            middle.Checked = false;
            low.Checked = false;
            item = null; 
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            if (!input_date())
            {
                return;
            }

            if (item == null)
            {
                MessageBox.Show("수정할 항목이 선택되지 않았습니다.", "알림");
                return;
            }
            string todo = item.SubItems[1].Text;
            string new_todo = textBox_t.Text.Trim();
            string newDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");

            int priority = 2;
            string priorityValue = "중간";
            if (high.Checked) { priority = 1; priorityValue = "높음"; }
            else if (low.Checked) { priority = 3; priorityValue = "낮음"; }
            
            try
            {

                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();

                    
                    string sql = "update `1101`.check_ToDo set todo = @new_todo, period = @newDate, priority = @priority where user_id = @user_id and todo = @todo";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {

                        cmd.Parameters.AddWithValue("@new_todo", new_todo);
                        cmd.Parameters.AddWithValue("@newDate", newDate );
                        cmd.Parameters.AddWithValue("@priority", priority);
                        cmd.Parameters.AddWithValue("@user_id", login_id);
                        cmd.Parameters.AddWithValue("@todo", todo);


                        int rowsAffected = cmd.ExecuteNonQuery();
                        
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("성공적으로 수정되었습니다.", "알림");

                            
                            item.SubItems[1].Text = new_todo;
                            item.SubItems[2].Text = newDate;
                            item.SubItems[3].Text = priorityValue;

                            if (f1 != null) f1.updateCheck(); 
                        }
                        else
                        {
                            MessageBox.Show("수정할 데이터가 없습니다.", "알림");
                        }
                    }
                }
                clearItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show("DB 저장 중 에러 발생: " + ex.Message, "오류");
            }
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearItems();
        }

        private void del_button_Click(object sender, EventArgs e)
        {
            if (item == null)
            {
                MessageBox.Show("삭제할 항목을 선택해주세요.", "알림");
                return;
            }

            DialogResult result = MessageBox.Show("삭제하시겠습니까?", "삭제 확인", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();

                        
                        string sql = "delete from `check_ToDo` where user_id = @user_id and todo = @todo";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            
                            string selectedTodo = item.SubItems[1].Text;

                            cmd.Parameters.AddWithValue("@user_id", login_id);
                            cmd.Parameters.AddWithValue("@todo", selectedTodo);

                            cmd.ExecuteNonQuery();
                            MessageBox.Show("DB에서 성공적으로 삭제되었습니다.", "알림");
                        }
                    }

                    
                    if (f1 != null)
                    {
                        f1.deleteItems(); 
                        f1.updateCheck(); 
                    }
                    clearItems();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("삭제 중 오류 발생: " + ex.Message, "오류");
                }
            }
        }

        private void save_button_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "텍스트 파일 (*.txt)|*.txt";
            sfd.FileName = "체크리스트.txt";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        foreach (ListViewItem lvItem in f1.listView1.Items)
                        {
                            string line = string.Format("{0}|{1}|{2}|{3}|{4}",
                                lvItem.Checked.ToString(),
                                lvItem.SubItems[1].Text,
                                lvItem.SubItems[2].Text,
                                lvItem.SubItems[3].Text,
                                lvItem.SubItems[4].Text
                            );
                            sw.WriteLine(line);
                        }
                    }
                    MessageBox.Show("성공적으로 저장되었습니다!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("에러 발생: " + ex.Message);
                }
            }
        }

        private void load_button_Click(object sender, EventArgs e)
        {
            bool checkError = false;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "텍스트 파일 (*.txt)|*.txt";
            ofd.Title = "체크리스트 불러오기";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (f1 != null) f1.listView1.Items.Clear();

                    string[] lines = File.ReadAllLines(ofd.FileName, Encoding.UTF8);

                    foreach (string line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        string[] data = line.Split('|');

                        if (data.Length >= 5)
                        {
                            ListViewItem newItem = new ListViewItem("");
                            newItem.Checked = bool.Parse(data[0]);
                            newItem.SubItems.Add(data[1]);
                            newItem.SubItems.Add(data[2]);
                            newItem.SubItems.Add(data[3]);
                            newItem.SubItems.Add(data[4]);

                            if (f1 != null) f1.listView1.Items.Add(newItem);
                        }
                        else
                        {
                            checkError = true;
                        }
                    }

                    if (f1 != null) f1.updateCheck();

                    if (checkError)
                        MessageBox.Show("손상되었거나 잘못된 데이터가 있습니다.", "알림");
                    else
                        MessageBox.Show("데이터를 성공적으로 불러왔습니다!", "알림");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("불러오기 중 오류가 발생했습니다: " + ex.Message, "오류");
                }
            }
        }

        private void add_button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인 정보가 없습니다.", "알림");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();

                    string sql = "INSERT INTO `check_share` (user_id, shared_id) VALUES (@user_id, @shared_id)";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", login_id);
                        cmd.Parameters.AddWithValue("@shared_id", share_id.Text.Trim());

                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("성공적으로 등록되었습니다.");
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("쿼리 실행 중 오류 발생: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("예기치 못한 오류: " + ex.Message);
            }
        }
    }
} // <-- 여기서 모든 클래스 명세가 안전하게 종료됩니다.