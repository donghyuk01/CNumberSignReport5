﻿namespace 과제4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            panel1 = new Panel();
            panel3 = new Panel();
            comboBox1 = new ComboBox();
            login_button = new Button();
            label2 = new Label();
            panel2 = new Panel();
            share = new Button();
            edit_dialog = new Button();
            label3 = new Label();
            label1 = new Label();
            textBox_state = new TextBox();
            textBox_today = new TextBox();
            search_button = new Button();
            textBox_search = new TextBox();
            progressBar1 = new ProgressBar();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.BackColor = Color.White;
            listView1.CheckBoxes = true;
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5 });
            listView1.Dock = DockStyle.Fill;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Location = new Point(0, 283);
            listView1.Margin = new Padding(6);
            listView1.Name = "listView1";
            listView1.Size = new Size(1351, 1061);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.ColumnClick += listView1_ColumnClick;
            listView1.ItemChecked += listView1_ItemChecked;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "상태";
            columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "할 일";
            columnHeader2.TextAlign = HorizontalAlignment.Center;
            columnHeader2.Width = 340;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "기한";
            columnHeader3.TextAlign = HorizontalAlignment.Center;
            columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "우선순위";
            columnHeader4.TextAlign = HorizontalAlignment.Center;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "추가 날짜";
            columnHeader5.TextAlign = HorizontalAlignment.Center;
            columnHeader5.Width = 100;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(1351, 74);
            panel1.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.SteelBlue;
            panel3.Controls.Add(comboBox1);
            panel3.Controls.Add(login_button);
            panel3.Controls.Add(label2);
            panel3.Location = new Point(3, 0);
            panel3.Margin = new Padding(4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1394, 77);
            panel3.TabIndex = 3;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(63, 19);
            comboBox1.Margin = new Padding(4, 3, 4, 3);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(292, 40);
            comboBox1.TabIndex = 2;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // login_button
            // 
            login_button.FlatStyle = FlatStyle.Flat;
            login_button.ForeColor = Color.White;
            login_button.Location = new Point(960, 13);
            login_button.Margin = new Padding(6);
            login_button.Name = "login_button";
            login_button.Size = new Size(297, 49);
            login_button.TabIndex = 1;
            login_button.Text = "로그인/회원가입";
            login_button.UseVisualStyleBackColor = true;
            login_button.Click += login_button_Click;
            // 
            // label2
            // 
            label2.Font = new Font("맑은 고딕", 14F, FontStyle.Bold, GraphicsUnit.Point, 129);
            label2.ForeColor = Color.White;
            label2.Location = new Point(424, 8);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(505, 60);
            label2.TabIndex = 0;
            label2.Text = "체크리스트";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(progressBar1);
            panel2.Controls.Add(share);
            panel2.Controls.Add(edit_dialog);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox_state);
            panel2.Controls.Add(textBox_today);
            panel2.Controls.Add(search_button);
            panel2.Controls.Add(textBox_search);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 74);
            panel2.Margin = new Padding(6);
            panel2.Name = "panel2";
            panel2.Size = new Size(1351, 209);
            panel2.TabIndex = 2;
            // 
            // share
            // 
            share.FlatStyle = FlatStyle.Flat;
            share.Location = new Point(1172, 27);
            share.Margin = new Padding(6);
            share.Name = "share";
            share.Size = new Size(88, 68);
            share.TabIndex = 8;
            share.Text = "공유";
            share.UseVisualStyleBackColor = true;
            share.Click += share_Click;
            // 
            // edit_dialog
            // 
            edit_dialog.FlatStyle = FlatStyle.Flat;
            edit_dialog.Location = new Point(963, 27);
            edit_dialog.Margin = new Padding(6);
            edit_dialog.Name = "edit_dialog";
            edit_dialog.Size = new Size(197, 68);
            edit_dialog.TabIndex = 7;
            edit_dialog.Text = "추가/편집";
            edit_dialog.UseVisualStyleBackColor = true;
            edit_dialog.Click += edit_dialog_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(63, 31);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(118, 32);
            label3.TabIndex = 6;
            label3.Text = "오늘 날짜";
            // 
            // label1
            // 
            label1.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(63, 115);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(57, 49);
            label1.TabIndex = 5;
            label1.Text = "⌕";
            // 
            // textBox_state
            // 
            textBox_state.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox_state.Location = new Point(963, 123);
            textBox_state.Margin = new Padding(6);
            textBox_state.Name = "textBox_state";
            textBox_state.ReadOnly = true;
            textBox_state.Size = new Size(300, 39);
            textBox_state.TabIndex = 2;
            textBox_state.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox_today
            // 
            textBox_today.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox_today.BackColor = SystemColors.MenuBar;
            textBox_today.Location = new Point(195, 27);
            textBox_today.Margin = new Padding(6);
            textBox_today.Name = "textBox_today";
            textBox_today.ReadOnly = true;
            textBox_today.Size = new Size(275, 39);
            textBox_today.TabIndex = 3;
            // 
            // search_button
            // 
            search_button.Anchor = AnchorStyles.Bottom;
            search_button.FlatStyle = FlatStyle.Flat;
            search_button.Location = new Point(750, 118);
            search_button.Margin = new Padding(6);
            search_button.Name = "search_button";
            search_button.Size = new Size(122, 50);
            search_button.TabIndex = 1;
            search_button.Text = "검색";
            search_button.UseVisualStyleBackColor = true;
            search_button.Click += search_button_Click;
            // 
            // textBox_search
            // 
            textBox_search.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox_search.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_search.Location = new Point(118, 118);
            textBox_search.Margin = new Padding(6);
            textBox_search.Name = "textBox_search";
            textBox_search.Size = new Size(617, 50);
            textBox_search.TabIndex = 0;
            textBox_search.TextChanged += textBox_search_TextChanged;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(963, 171);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(300, 29);
            progressBar1.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1351, 1344);
            Controls.Add(listView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            ForeColor = Color.Black;
            Margin = new Padding(6);
            MaximumSize = new Size(1377, 1639);
            MinimumSize = new Size(1377, 1268);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "체크리스트";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox_search;
        private TextBox textBox_state;
        private Button search_button;
        private Label label1;
        private TextBox textBox_today;
        private Label label2;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private Label label3;
        private Button edit_dialog;
        public ListView listView1;
        private Button share;
        private Button login_button;
        public ComboBox comboBox1;
        private Panel panel3;
        private ProgressBar progressBar1;
    }
}
