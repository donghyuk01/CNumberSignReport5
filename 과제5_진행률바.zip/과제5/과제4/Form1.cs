using Microsoft.VisualBasic.Devices;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Text;

namespace 과제4
{
    public partial class Form1 : Form
    {
        int screenWidth = Screen.PrimaryScreen.Bounds.Width;
        int screenHeight = Screen.PrimaryScreen.Bounds.Height;

        Form2 f2;
        Form3 f3;
        public int isLogin; //0: 로그인 1: 로그아웃
        private string login_id = "";
        string connStr = "Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd=civil5949;CharSet=utf8mb4;";
        public Form1()
        {
            InitializeComponent();
            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ListViewItem item = new ListViewItem("");
            isLogin = 1;
            edit_dialog.BackColor = Color.Gray;
            share.BackColor = Color.Gray;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(50, 150);
            this.Size=new Size((int)(screenWidth*0.4),(int)(screenHeight*0.8));

            int totalWidth = listView1.ClientSize.Width; //전체 너비 가지고 옴.

            listView1.Columns[0].Width = (int)(totalWidth * 0.10); // 상태 (10%)
            listView1.Columns[1].Width = (int)(totalWidth * 0.45); // 할 일 (45%)
            listView1.Columns[2].Width = (int)(totalWidth * 0.15); // 기한 (15%)
            listView1.Columns[3].Width = (int)(totalWidth * 0.15); // 우선순위 (15%)
            listView1.Columns[4].Width = (int)(totalWidth * 0.15); // 추가 날짜 (15%)

        }
        public string set_id
        {
            set
            {
                login_id = value;
                comboBox1.Items.Add(value);
                comboBox1.SelectedItem = value;
                label2.Text = value + "님의 체크리스트";
                isLogin = 0;
                login_button.Text = "로그아웃";
                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
                AddShareId();
                LoadItems();
            }
        }
        public void AddShareId()
        {
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "select user_id from `1101`.check_share where shared_id = @shared_id";
                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@shared_id", login_id);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        listView1.Items.Clear();
                        while (reader.Read())
                        {
                            string id = Convert.ToString(reader["user_id"]);
                            comboBox1.Items.Add(id);
                        }
                    }
                }
            }
        }
        public void AddToListView(string todo, string dueDate, string priority, string date, object db_id = null, bool isChecked = false)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(date);
            listView1.Items.Add(item);

            if (db_id != null)
            {
                item.Tag = db_id;
            }
            item.Checked = isChecked;
        }
        private void LoadItems()
        {
            if (string.IsNullOrEmpty(login_id))
            {
                listView1.Items.Clear();
            }
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "select id_check_ToDo, todo, period, priority, status, dateTime from `1101`.check_ToDo where user_id = @user_id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", comboBox1.SelectedItem);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            listView1.Items.Clear();
                            while (reader.Read())
                            {

                                object db_id = reader["id_check_ToDo"];
                                string todo = Convert.ToString(reader["todo"]);
                                string dueDate = Convert.ToString(reader["period"]);
                                string date = Convert.ToDateTime(reader["dateTime"]).ToString("yyyy-MM-dd");

                                string priorityStr = "중간";
                                int p = Convert.ToInt32(reader["priority"]);
                                if (p == 1) priorityStr = "높음";
                                else if (p == 3) priorityStr = "낮음";


                                bool isChecked = Convert.ToString(reader["status"]) == "완료";


                                AddToListView(todo, dueDate, priorityStr, date, db_id, isChecked);
                            }
                        }
                    }
                }
                updateCheck();
                change_color();
            }
            catch (Exception e)
            {
                MessageBox.Show("데이터를 가져오는 중 오류가 발생했습니다:\n" + e, "오류");
            }
            foreach (ColumnHeader col in listView1.Columns)
            {
                col.Width = -2; // 내용 길이에 맞춤 (헤더가 더 길면 -1)
            }
        }
        private void OpenOrActivateForm2(Size? customSize = null)
        {
            // 클릭하는 "현재 시점"에 실제로 열려있는 Form2를 찾습니다.
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 서비스입니다.");
                return;
            }
            f2 = Application.OpenForms["Form2"] as Form2;

            if (f2 == null || f2.IsDisposed)
            {
                // 열려있지 않거나 닫혔다면 새로 생성
                f2 = new Form2(this, login_id);
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                // 사용자가 Form2를 닫으면 전역 변수 f2도 null로 초기화하여 중복 방지
                f2.FormClosed += (s, args) => { f2 = null; };
                f2.Show();
            }
            else
            {
                // 이미 열려 있다면 위치/크기 조정 후 앞으로 가져오기
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.Activate();
            }

        }
        private void edit_dialog_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;
            OpenOrActivateForm2(new Size((int)(screenWidth*0.35), (int)(screenHeight*0.20)));
            f2.SetPenel = false;
        }

        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            bool find = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[1].Text.Contains(s))
                {
                    item.BackColor = Color.FromArgb(189, 252, 201);
                    item.EnsureVisible(); //항목 위치로 스크롤되게 
                    //textBox_search.Clear();
                    find = true;
                }
                //else
                //{
                //    item.BackColor = Color.White;
                //}
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;     // 할 일
                string thirdColumn = item.SubItems[2].Text;     // 날짜
                string forthColumn = item.SubItems[3].Text;     // 우선순위
                if (f2 != null)
                {
                    f2.SetToDo = secondColumn;
                    f2.SetDate = (DateTime.Parse(thirdColumn) > DateTime.Today) ? thirdColumn : (DateTime.Today).ToString();
                    f2.SetSelect = forthColumn;
                    f2.SetItem = item;
                }

            }
        }
        public void deleteItems()
        {
            int c = listView1.SelectedItems.Count;
            if (c > 0)
            {
                for (int i = c - 1; i >= 0; i--)
                {
                    listView1.Items.Remove(listView1.SelectedItems[i]);
                }
            }
        }

        private int sortColumn = -1;
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == sortColumn)
            {
                // 같은 열 클릭시 오름차순/내림차순 토글
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                // 다른 열 클릭시 오름차순으로 시작
                sortColumn = e.Column;
                listView1.Sorting = SortOrder.Ascending;
            }

            listView1.ListViewItemSorter = new ListViewItemComparer(sortColumn, listView1.Sorting);
            // 사용이유 ListViewItemSorter ListView의 정렬 방법 정의
            // 높음, 중간, 낮음이 기존 정렬로는 정렬이 안됨 낮음->높음->중간 순
            // 그래서 정렬 방법을 아이템 3번만 정의
            // IComparer 인터페이스로만 받을수 있어서 클래스 새롭게 정의함
            listView1.Sort();
        }
        public void updateCheck()
        {
            int total = listView1.Items.Count;
            int count = listView1.CheckedItems.Count;

            textBox_state.Text = $"완료된 할 일: {count} / {total}";
            if (total > 0)
            {
                progressBar1.Minimum = 0;
                progressBar1.Maximum = 100;

                progressBar1.Value = (int)((double)count / total * 100);
            }
            else
            {
                progressBar1.Value = 0;
            }
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            updateCheck();
            if (e.Item != null && e.Item.Tag != null)
            {
                object db_id = e.Item.Tag;
                string newStatus = e.Item.Checked ? "완료" : "미완료";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "update `1101`.check_ToDo set status = @status where id_check_ToDo = @id";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@status", newStatus);
                            cmd.Parameters.AddWithValue("@id", db_id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
                }
            }
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_search.Text))
            {
                // 검색 창을 지웠을때 작동
                foreach (ListViewItem item in listView1.Items)
                {
                    item.BackColor = Color.White;
                }
                change_color();
            }
        }

        private void share_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;
            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.25)));
            f2.SetPenel = true;
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            if (isLogin == 0) // 로그인 상태인경우 로그아웃 처리
            {
                DialogResult result = MessageBox.Show(
                    "로그아웃을 하시겠습니까?",   // 메시지 내용
                    "경고",                     // 제목
                    MessageBoxButtons.OKCancel, // 버튼 종류 (확인, 취소)
                    MessageBoxIcon.Warning      // 아이콘 (경고)
                );
                // 버튼 결과 처리
                if (result == DialogResult.OK)
                {
                    MessageBox.Show("로그아웃 되었습니다.");
                    login_button.Text = "로그인/회원가입";
                    label2.Text = "체크리스트";
                    listView1.Items.Clear();
                    comboBox1.Items.Clear();
                    comboBox1.Text = "";
                    isLogin = 1;
                }
                else if (result == DialogResult.Cancel)
                {
                    this.Close();
                }
                return;
            }
            Form existingForm = Application.OpenForms["Form3"];

            if (existingForm == null)
            {
                // 없으면 새로 열기
                Form3 f3 = new Form3(this);

                // 위치를 직접 지정하려면 StartPosition을 Manual로 설정
                f3.StartPosition = FormStartPosition.Manual;
                f3.Size = new Size((int)(screenWidth*0.35), (int)(screenHeight*0.2));
                // 원하는 좌표 지정 (예: 화면 왼쪽 위에서 100, 200 위치)
                f3.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                f3.Show();
            }
            else
            {
                existingForm.StartPosition = FormStartPosition.Manual;
                existingForm.Size = new Size(480, 250);
                existingForm.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                // 이미 열려 있으면 앞으로 가져오기
                existingForm.Activate();
            }

        }

        private void change_color()
        {
            foreach (ListViewItem item in listView1.Items)
            {
                string p = item.SubItems[2].Text;
                if (DateTime.TryParse(p, out DateTime period))
                {
                    DateTime today = DateTime.Today;
                    TimeSpan t = period.Date - today;
                    int remain = t.Days;
                    if (remain < 0)
                    {
                        item.BackColor = Color.DimGray;
                    }
                    else if (remain == 0)
                    {
                        item.BackColor = Color.Red;
                    }
                    else if (remain <= 7)
                    {
                        item.BackColor = Color.Orange;
                    }
                    else if (remain <= 14)
                    {
                        item.BackColor = Color.Yellow;
                    }
                    else
                    {
                        item.BackColor = Color.White;
                    }
                }
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
            {
                edit_dialog.BackColor = Color.Gray;
                share.BackColor = Color.Gray;
            }
            else {
                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
            }
            LoadItems();
        }
    }
}
public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder order)
    {
        col = column;
        this.order = order;
    }

    public int Compare(object x, object y)
    {
        string textX = ((ListViewItem)x).SubItems[col].Text;
        string textY = ((ListViewItem)y).SubItems[col].Text;

        int result;

        if (col == 3)  // 우선순위 열 커스텀 정렬
        {
            string[] order_list = { "낮음", "중간", "높음" };
            int indexX = Array.IndexOf(order_list, textX);
            int indexY = Array.IndexOf(order_list, textY);
            result = indexX.CompareTo(indexY);
        }
        else
        {
            result = String.Compare(textX, textY);
        }

        return order == SortOrder.Ascending ? result : -result;
    }

}