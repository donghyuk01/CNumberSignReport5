﻿namespace 과제4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button1 = new Button();
            low = new RadioButton();
            middle = new RadioButton();
            high = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            add_button = new Button();
            textBox_t = new MaskedTextBox();
            del_button = new Button();
            edit_button = new Button();
            save_button = new Button();
            load_button = new Button();
            share_id = new TextBox();
            label1 = new Label();
            add_button2 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(button1);
            panel1.Controls.Add(low);
            panel1.Controls.Add(middle);
            panel1.Controls.Add(high);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(add_button);
            panel1.Controls.Add(textBox_t);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(1049, 310);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(900, 253);
            button1.Margin = new Padding(6);
            button1.Name = "button1";
            button1.Size = new Size(113, 49);
            button1.TabIndex = 4;
            button1.Text = "초기화";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // low
            // 
            low.AutoSize = true;
            low.Location = new Point(444, 183);
            low.Margin = new Padding(6);
            low.Name = "low";
            low.Size = new Size(93, 36);
            low.TabIndex = 3;
            low.TabStop = true;
            low.Text = "낮음";
            low.UseVisualStyleBackColor = true;
            // 
            // middle
            // 
            middle.AutoSize = true;
            middle.Location = new Point(242, 183);
            middle.Margin = new Padding(6);
            middle.Name = "middle";
            middle.Size = new Size(93, 36);
            middle.TabIndex = 3;
            middle.TabStop = true;
            middle.Text = "중간";
            middle.UseVisualStyleBackColor = true;
            // 
            // high
            // 
            high.AutoSize = true;
            high.Location = new Point(41, 183);
            high.Margin = new Padding(6);
            high.Name = "high";
            high.Size = new Size(93, 36);
            high.TabIndex = 3;
            high.TabStop = true;
            high.Text = "높음";
            high.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(696, 87);
            dateTimePicker1.Margin = new Padding(6);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(316, 39);
            dateTimePicker1.TabIndex = 2;
            // 
            // add_button
            // 
            add_button.Location = new Point(696, 163);
            add_button.Margin = new Padding(6);
            add_button.Name = "add_button";
            add_button.Size = new Size(321, 83);
            add_button.TabIndex = 1;
            add_button.Text = "추가";
            add_button.UseVisualStyleBackColor = true;
            add_button.Click += add_button_Click;
            // 
            // textBox_t
            // 
            textBox_t.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_t.Location = new Point(28, 74);
            textBox_t.Margin = new Padding(6);
            textBox_t.Name = "textBox_t";
            textBox_t.Size = new Size(602, 50);
            textBox_t.TabIndex = 0;
            // 
            // del_button
            // 
            del_button.Location = new Point(41, 323);
            del_button.Margin = new Padding(6);
            del_button.Name = "del_button";
            del_button.Size = new Size(181, 92);
            del_button.TabIndex = 1;
            del_button.Text = "삭제";
            del_button.UseVisualStyleBackColor = true;
            del_button.Click += del_button_Click;
            // 
            // edit_button
            // 
            edit_button.Location = new Point(242, 323);
            edit_button.Margin = new Padding(6);
            edit_button.Name = "edit_button";
            edit_button.Size = new Size(181, 92);
            edit_button.TabIndex = 1;
            edit_button.Text = "편집";
            edit_button.UseVisualStyleBackColor = true;
            edit_button.Click += edit_button_Click;
            // 
            // save_button
            // 
            save_button.Location = new Point(718, 323);
            save_button.Margin = new Padding(6);
            save_button.Name = "save_button";
            save_button.Size = new Size(120, 92);
            save_button.TabIndex = 1;
            save_button.Text = "저장";
            save_button.UseVisualStyleBackColor = true;
            save_button.Click += save_button_Click;
            // 
            // load_button
            // 
            load_button.Location = new Point(850, 323);
            load_button.Margin = new Padding(6);
            load_button.Name = "load_button";
            load_button.Size = new Size(134, 92);
            load_button.TabIndex = 1;
            load_button.Text = "불러오기";
            load_button.UseVisualStyleBackColor = true;
            load_button.Click += load_button_Click;
            // 
            // share_id
            // 
            share_id.Location = new Point(41, 525);
            share_id.Name = "share_id";
            share_id.Size = new Size(229, 39);
            share_id.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(60, 479);
            label1.Name = "label1";
            label1.Size = new Size(189, 32);
            label1.TabIndex = 3;
            label1.Text = "공유하고싶은 ID";
            // 
            // add_button2
            // 
            add_button2.Location = new Point(309, 481);
            add_button2.Margin = new Padding(6);
            add_button2.Name = "add_button2";
            add_button2.Size = new Size(114, 83);
            add_button2.TabIndex = 5;
            add_button2.Text = "추가";
            add_button2.UseVisualStyleBackColor = true;
            add_button2.Click += add_button2_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1049, 598);
            Controls.Add(add_button2);
            Controls.Add(label1);
            Controls.Add(share_id);
            Controls.Add(load_button);
            Controls.Add(save_button);
            Controls.Add(edit_button);
            Controls.Add(del_button);
            Controls.Add(panel1);
            Margin = new Padding(6);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private RadioButton middle;
        private RadioButton high;
        private DateTimePicker dateTimePicker1;
        private Button add_button;
        private MaskedTextBox textBox_t;
        private RadioButton low;
        private Button del_button;
        private Button edit_button;
        private Button save_button;
        private Button load_button;
        private Button button1;
        private TextBox share_id;
        private Label label1;
        private Button add_button2;
    }
}