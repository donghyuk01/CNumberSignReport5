﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 과제4
{
    public partial class Form3 : Form
    {
        Form1 f1;
        string connStr = "Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd=civil5949;";
        public int isLogin_mode; //0: 로그인 1:회원가입
        
        public Form3()
        {
            InitializeComponent();
            isLogin_mode = 0;
        }
        public Form3(Form1 f)
        {
            InitializeComponent();
            isLogin_mode = 0;
            f1 = f;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (isLogin_mode == 0)
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();

                        string sql = "select user_id, user_pwd from `1101`.check_user where user_id = @user_id and user_pwd = @user_pwd";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            
                            cmd.Parameters.AddWithValue("@user_id", login.Text);
                            cmd.Parameters.AddWithValue("@user_pwd", pwd.Text);
                            
                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {

                                if (reader.Read())
                                {
                                    MessageBox.Show("로그인 성공");
                                    f1.isLogin = 0;
                                    f1.set_id = login.Text;
                                    f1.Show();
                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("아이디와 비밀번호가 일치하지 않습니다.");
                                }
                            }

                        }
                    }
                }
                catch (MySqlException ex)
                {
                    // MySQL 관련 에러 처리
                    MessageBox.Show("쿼리 실행 중 오류 발생: " + ex.Message);
                }
                catch (Exception ex)
                {
                    // 일반적인 예외 처리
                    MessageBox.Show("예기치 못한 오류: " + ex);
                }

            }
            else if(isLogin_mode == 1)
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();

                        string sql = "INSERT INTO `1101`.`check_user`(user_id,user_pwd) VALUES(@user_id, @user_pwd)";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            // 파라미터 바인딩
                            //cmd.Parameters.AddWithValue("@user_id", user_id.Text);
                            cmd.Parameters.AddWithValue("@user_id", login.Text);
                            cmd.Parameters.AddWithValue("@user_pwd", pwd.Text);
                            // 실행
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show("성공적으로 등록되었습니다.");
                            Login_mode();
                            
                        }

                    }
                    
                }
                catch (MySqlException ex)
                {
                    // MySQL 관련 에러 처리
                    MessageBox.Show("쿼리 실행 중 오류 발생: " + ex);
                }
                catch (Exception ex)
                {
                    // 일반적인 예외 처리
                    MessageBox.Show("예기치 못한 오류: " + ex.Message);
                }
            }

        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login_mode();
           
        }
        private void Login_mode()
        {
            if (isLogin_mode == 0)
            {
                label1.Text = "회원가입";
                button1.Text = "회원가입";
                linkLabel1.Text = "로그인";
                isLogin_mode = 1;
            }
            else if (isLogin_mode == 1)
            {
                label1.Text = "로그인";
                button1.Text = "로그인";
                linkLabel1.Text = "회원가입";
                isLogin_mode = 0;

            }
        }

    }
}
